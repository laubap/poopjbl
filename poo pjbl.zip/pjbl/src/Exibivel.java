interface Exibivel {
    void exibirDetalhes();
}
